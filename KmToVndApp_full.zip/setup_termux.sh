#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "Updating packages..."
pkg update -y && pkg upgrade -y
echo "Installing dependencies..."
pkg install -y openjdk-17 gradle git unzip nodejs
echo "Ensure Android SDK command-line tools are installed manually (see README)."
echo "Building APK (may take several minutes)..."
# Try gradle wrapper if exists otherwise gradle
if [ -f ./gradlew ]; then
  chmod +x ./gradlew
  ./gradlew assembleDebug
else
  gradle assembleDebug
fi
echo "APK should be at app/build/outputs/apk/debug/app-debug.apk"
