package com.example.km2vnd

data class WithdrawRequest(val phone: String, val amount: Long, val note: String?)
data class WithdrawResponse(val success: Boolean, val message: String?)
