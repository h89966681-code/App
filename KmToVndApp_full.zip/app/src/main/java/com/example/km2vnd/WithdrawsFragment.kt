package com.example.km2vnd

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class WithdrawsFragment : Fragment() {
    private lateinit var rv: RecyclerView
    private lateinit var adapter: WithdrawAdapter
    private lateinit var btnDemo: Button
    private lateinit var btnReal: Button

    // Demo backend URL - change in settings or build config
    private val BASE_URL = "https://your-backend.example.com"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_withdraws, container, false)
        rv = v.findViewById(R.id.rvWithdraws)
        rv.layoutManager = LinearLayoutManager(requireContext())
        adapter = WithdrawAdapter()
        rv.adapter = adapter

        btnDemo = v.findViewById(R.id.btnDemoWithdraw)
        btnReal = v.findViewById(R.id.btnRealWithdraw)

        btnDemo.setOnClickListener { doDemoWithdraw() }
        btnReal.setOnClickListener { doRealWithdraw() }

        loadList()
        return v
    }

    private fun loadList() {
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getInstance(requireContext())
            val items = db.withdrawDao().getAll()
            CoroutineScope(Dispatchers.Main).launch { adapter.setItems(items) }
        }
    }

    private fun doDemoWithdraw() {
        // find latest run to withdraw or use a fixed amount
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getInstance(requireContext())
            val runs = db.runDao().getAll()
            val amount = if (runs.isNotEmpty()) runs.last().money else 1000L
            val entry = WithdrawEntry(0, System.currentTimeMillis(), amount, "demo", true)
            db.withdrawDao().insert(entry)
            CoroutineScope(Dispatchers.Main).launch {
                Toast.makeText(requireContext(), "Rút demo thành công: ${'$'}{amount} đ", Toast.LENGTH_SHORT).show()
                loadList()
            }
        }
    }

    private fun doRealWithdraw() {
        // call backend (requires proper backend)
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getInstance(requireContext())
            val runs = db.runDao().getAll()
            if (runs.isEmpty()) {
                CoroutineScope(Dispatchers.Main).launch { Toast.makeText(requireContext(), "Không có tiền để rút", Toast.LENGTH_SHORT).show() }
                return@launch
            }
            val amount = runs.last().money
            try {
                val retrofit = Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build()
                val api = retrofit.create(WithdrawApi::class.java)
                val req = WithdrawRequest("0900000000", amount, "Rút từ app")
                val resp = api.withdraw(req).execute()
                val success = resp.isSuccessful && resp.body()?.success == true
                val entry = WithdrawEntry(0, System.currentTimeMillis(), amount, resp.body()?.message ?: "", success)
                db.withdrawDao().insert(entry)
                CoroutineScope(Dispatchers.Main).launch {
                    Toast.makeText(requireContext(), if (success) "Rút thành công" else "Rút thất bại", Toast.LENGTH_SHORT).show()
                    loadList()
                }
            } catch (e: Exception) {
                val entry = WithdrawEntry(0, System.currentTimeMillis(), amount, e.message ?: "error", false)
                db.withdrawDao().insert(entry)
                CoroutineScope(Dispatchers.Main).launch {
                    Toast.makeText(requireContext(), "Lỗi khi gọi backend", Toast.LENGTH_SHORT).show()
                    loadList()
                }
            }
        }
    }

interface WithdrawApi {
    @retrofit2.http.POST("/api/withdraw")
    fun withdraw(@retrofit2.http.Body req: WithdrawRequest): retrofit2.Call<WithdrawResponse>
}
