package com.example.km2vnd

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RunsFragment : Fragment() {
    private lateinit var rv: RecyclerView
    private lateinit var adapter: RunsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_runs, container, false)
        rv = v.findViewById(R.id.rvRuns)
        rv.layoutManager = LinearLayoutManager(requireContext())
        adapter = RunsAdapter()
        rv.adapter = adapter

        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getInstance(requireContext())
            val runs = db.runDao().getAll()
            CoroutineScope(Dispatchers.Main).launch { adapter.setItems(runs) }
        }
        return v
    }
}
