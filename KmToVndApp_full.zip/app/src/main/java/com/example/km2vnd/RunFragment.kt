package com.example.km2vnd

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.google.android.gms.location.*

class RunFragment : Fragment() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private var lastLocation: Location? = null
    private var totalDistance = 0f

    private lateinit var tvDistance: TextView
    private lateinit var tvMoney: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    private var tracking = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_run, container, false)
        tvDistance = v.findViewById(R.id.tvDistance)
        tvMoney = v.findViewById(R.id.tvMoney)
        btnStart = v.findViewById(R.id.btnStart)
        btnStop = v.findViewById(R.id.btnStop)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())

        btnStart.setOnClickListener { startTracking() }
        btnStop.setOnClickListener { stopTrackingAndSave() }
        return v
    }

    private fun startTracking() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }
        tracking = true
        totalDistance = 0f
        lastLocation = null

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000).build()
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                for (location in result.locations) {
                    if (lastLocation != null) {
                        totalDistance += lastLocation!!.distanceTo(location)
                        updateUI()
                    }
                    lastLocation = location
                }
            }
        }
        fusedLocationClient.requestLocationUpdates(request, locationCallback, requireActivity().mainLooper)
    }

    private fun stopTrackingAndSave() {
        if (!tracking) return
        tracking = false
        fusedLocationClient.removeLocationUpdates(locationCallback)
        updateUI()
        // save to DB
        val km = totalDistance / 1000.0
        val money = (km * 800).toLong()
        // save asynchronously
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getInstance(requireContext())
            db.runDao().insert(RunEntry(0, System.currentTimeMillis(), km, money))
        }
    }

    private fun updateUI() {
        val km = totalDistance / 1000.0
        val money = (km * 800)
        tvDistance.text = "Quãng đường: %.2f km".format(km)
        tvMoney.text = "Số tiền: %.0f đ".format(money)
    }
}
