package com.example.km2vnd

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WithdrawAdapter : RecyclerView.Adapter<WithdrawAdapter.VH>() {
    private var items: List<WithdrawEntry> = emptyList()
    fun setItems(list: List<WithdrawEntry>) { items = list; notifyDataSetChanged() }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false)
        return VH(v)
    }
    override fun onBindViewHolder(holder: VH, position: Int) {
        val it = items[position]
        holder.title.text = "${'$'}{it.amount} đ - ${'$'}{if (it.success) "OK" else "FAIL"}"
        holder.subtitle.text = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(java.util.Date(it.timestamp))
    }
    override fun getItemCount(): Int = items.size
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(android.R.id.text1)
        val subtitle: TextView = v.findViewById(android.R.id.text2)
    }
}
