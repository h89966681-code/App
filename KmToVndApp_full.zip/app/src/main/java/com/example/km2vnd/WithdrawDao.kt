package com.example.km2vnd

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface WithdrawDao {
    @Query("SELECT * FROM withdraws ORDER BY timestamp ASC")
    fun getAll(): List<WithdrawEntry>

    @Insert
    fun insert(entry: WithdrawEntry)
}
