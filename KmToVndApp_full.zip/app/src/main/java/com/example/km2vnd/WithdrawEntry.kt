package com.example.km2vnd

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "withdraws")
data class WithdrawEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val amount: Long,
    val note: String,
    val success: Boolean
)
