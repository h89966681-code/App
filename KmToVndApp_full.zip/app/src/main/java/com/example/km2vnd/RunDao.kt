package com.example.km2vnd

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface RunDao {
    @Query("SELECT * FROM runs ORDER BY timestamp ASC")
    fun getAll(): List<RunEntry>

    @Insert
    fun insert(entry: RunEntry)
}
