package com.example.km2vnd

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottom = findViewById<BottomNavigationView>(R.id.bottom_nav)
        // default
        supportFragmentManager.beginTransaction().replace(R.id.fragment_container, RunFragment()).commit()

        bottom.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_run -> supportFragmentManager.beginTransaction().replace(R.id.fragment_container, RunFragment()).commit()
                R.id.menu_history_run -> supportFragmentManager.beginTransaction().replace(R.id.fragment_container, RunsFragment()).commit()
                R.id.menu_withdraw -> supportFragmentManager.beginTransaction().replace(R.id.fragment_container, WithdrawsFragment()).commit()
            }
            true
        }
    }
}
