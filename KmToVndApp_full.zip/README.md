# KmToVndApp - Full (Demo + Real)

Includes:
- Android app (Kotlin) with BottomNavigation (Run, History Run, History Withdraw)
- Room DB for saving runs and withdraws
- Demo withdraw (local) and Real withdraw mode (calls backend /api/withdraw)
- Termux setup script to build APK
- Backend sample (momo-backend) to handle real withdraw requests (you must provide MoMo credentials)

## Quick steps (Termux)
1. Copy the project to your device (this zip).
2. Run `termux-setup-storage` to allow access if you need to copy SDK tools.
3. Install Android SDK command-line tools manually and set `ANDROID_HOME` environment variable. See previous messages for detailed steps.
4. Make script executable: `chmod +x setup_termux.sh` then `./setup_termux.sh`.
5. After build, APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Backend (real withdraw)
See `momo-backend` folder. Fill `.env` with your MoMo merchant credentials and run `node server.js`.

## Notes
- Real withdraw requires proper MoMo merchant account and reading their API documentation.
- App uses Location APIs (FusedLocationProvider). You must grant location permission.
