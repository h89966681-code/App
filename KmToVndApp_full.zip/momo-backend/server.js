require('dotenv').config();
const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const fs = require('fs-extra');
const app = express();
app.use(bodyParser.json());
const DBFILE = './withdraws.json';
async function saveWithdraw(record){
  let arr = [];
  try { arr = await fs.readJson(DBFILE); } catch(e) { arr = [] }
  arr.push(record);
  await fs.writeJson(DBFILE, arr, {spaces:2});
}

const MOMO_API = process.env.MOMO_ENV === 'production' ? 'https://api.momo.vn' : 'https://test-payment.momo.vn';

app.post('/api/withdraw', async (req, res) => {
  try {
    const { phone, amount, note } = req.body;
    if (!phone || !amount) return res.status(400).json({ success:false, message: 'Thiếu tham số' });
    // Here you must implement actual MoMo request per their spec.
    // This sample will simulate success when MOMO_SIMULATE=1, otherwise return error to show flow.
    const simulate = process.env.MOMO_SIMULATE === '1';
    const record = { timestamp: Date.now(), phone, amount, note, success: simulate };
    await saveWithdraw(record);
    if (simulate) return res.json({ success:true, message: 'Simulated withdraw successful' });
    return res.status(500).json({ success:false, message: 'Not implemented: integrate MoMo API per docs' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success:false, message: 'Internal error' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('Server running on', PORT));
